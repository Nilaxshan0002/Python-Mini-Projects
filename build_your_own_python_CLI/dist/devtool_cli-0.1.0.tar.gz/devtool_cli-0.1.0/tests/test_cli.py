from typer.testing import CliRunner
from devtool.cli import app
from devtool.database import get_connection
import os
import pytest

# Initialize the test runner
runner = CliRunner()

@pytest.fixture(autouse=True)
def cleanup_database():
    """Fixture to delete the test database before/after each test."""
    from devtool.database import DB_PATH
    
    # 1. Cleanup before test
    if os.path.exists(DB_PATH):
        try:
            os.remove(DB_PATH)
        except PermissionError:
            # Force close any lingering connections
            conn = get_connection()
            conn.close()
            os.remove(DB_PATH)
    
    yield
    
    # 2. Cleanup after test
    if os.path.exists(DB_PATH):
        try:
            os.remove(DB_PATH)
        except PermissionError:
            # Force close any lingering connections
            conn = get_connection()
            conn.close()
            os.remove(DB_PATH)

def test_help_command():
    """Test that the help menu works."""
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "devtool" in result.stdout

def test_add_and_list():
    """Test adding a note and then listing it."""
    # 1. Test adding
    result_add = runner.invoke(app, ["add", "Test Title", "-c", "Test Content"])
    assert result_add.exit_code == 0
    assert "Note added with ID 1" in result_add.stdout

    # 2. Test listing
    result_list = runner.invoke(app, ["list"])
    assert result_list.exit_code == 0
    assert "Test Title" in result_list.stdout
    assert "Test Content" in result_list.stdout

def test_delete_note():
    """Test adding a note and deleting it."""
    # Add a note
    runner.invoke(app, ["add", "To Be Deleted"])
    
    # Delete it (simulating the user typing 'y' for confirm)
    result = runner.invoke(app, ["delete", "1"], input="y\n")
    assert result.exit_code == 0
    assert "deleted successfully" in result.stdout
    
    # Verify it's gone
    result_list = runner.invoke(app, ["list"])
    assert "To Be Deleted" not in result_list.stdout